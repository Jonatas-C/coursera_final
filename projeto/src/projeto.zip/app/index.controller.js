(function() {

    'use strict';

    angular
        .module('rin')
        .controller('AppController', AppController);




    /** @ngInject */
	function AppController( $scope )  {

        var vm = this;



    }

})();
