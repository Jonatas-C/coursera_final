(function() {

    'use strict';

    angular
        .module('rin')
        .config(config);

    /** @ngInject */
    function config() {

    }
})();
