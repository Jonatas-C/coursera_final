(function() {
    
    'use strict';

    angular
        .module('rin')
        .run(runBlock);

    /** @ngInject */
    function runBlock() {

    }
})();