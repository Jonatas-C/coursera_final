(function() {
	
	'use strict';

	angular
		.module('app.register')
		.controller('RegisterController', RegisterController);

	function RegisterController() {

        var vm = this;
        
    }

})();
