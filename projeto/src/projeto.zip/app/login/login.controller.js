(function() {
    
    'use strict';

    angular
        .module('app.login')
        .controller('LoginController', LoginController);

    /** @ngInject */
    function LoginController() {

        var vm = this;
        
    }

})();