(function() {
    
    'use strict';

    angular
        .module('app.sidebar', [])
        .config(config);

    /** @ngInject */
    function config() {
    	
    }

})();
