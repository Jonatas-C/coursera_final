(function() {
    
    'use strict';

    angular
        .module('app.sidebar')
        .controller('SidebarController', SidebarController);

    /** @ngInject */
    function SidebarController() {

        var vm = this;
        
    }

})();


