(function ()
{
    'use strict';

    angular
        .module('app.topbar', [])
        .config(config);

    /** @ngInject */
    function config() {

        var vm = this;
        
    }

})();
